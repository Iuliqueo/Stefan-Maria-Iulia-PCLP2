import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int number,sum,a,b;
        System.out.println("Write a value for number: ");
        number = input.nextInt();
        input.close();

        a = number % 10;
        number /= 10;
        b = number % 10;
        number /= 10;

        sum = a + b + number;
        System.out.println(sum);




    }
}