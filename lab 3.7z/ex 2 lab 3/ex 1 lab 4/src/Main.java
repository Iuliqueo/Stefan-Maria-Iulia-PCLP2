import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int[] tab;
        int dim, max, max2;
        System.out.println("Write the number of elements: ");
        dim = input.nextInt();
        tab = new int[dim];
        for (int i = 0; i < dim; i++) {
            tab[i] =(int) input.nextInt();
        }
        input.close();
        max = tab[0];
        for (int i = 0; i < dim; i++) {
            if (tab[i] > max) {
                max = tab[i];
            }
        }
        max2 = tab[0];

        for (int i = 0; i < dim; i++) {
            if (max2 < tab[i]) {
                if (max > max2) {
                    max2 = tab[i];
                }
            }
        }
        System.out.println(max2);

    }
}