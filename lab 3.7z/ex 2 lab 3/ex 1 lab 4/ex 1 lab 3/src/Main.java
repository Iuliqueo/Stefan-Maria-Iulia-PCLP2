import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int number;
        System.out.println("Write a value for number: ");
        number = input.nextInt();
        input.close();

        if(number > 0){
            System.out.println("Number is possitive");
        }
        else if (number < 0){
            System.out.println("Number is negative");
        }
        else if (number == 0){
            System.out.println("Number is NULL");
        }

    }
}