import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int[] matrix;
        int dim = input.nextInt();
        int j = 0;
        matrix = new int[4];


        System.out.println("Write numbers for matrix: ");
        for (int i = 0; i < 4; i++) {
            matrix[i] = input.nextInt();
        }

        for (int i = 0; i < matrix.length - 1; i++) {
            if(matrix[i] != matrix[i+1]){
                matrix[j++] = matrix[i];
            }
        }
    }
}