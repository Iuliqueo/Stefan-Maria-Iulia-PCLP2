import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int nrLinii;
        int nrColoane;

        System.out.println("Introduceti numarului de linii al matricei: ");
        nrLinii = input.nextInt();

        System.out.println("Introduceti numarul de coloane al matricei: ");
        nrColoane = input.nextInt();

        int [][]matrix=new int[nrLinii][nrColoane];

        System.out.println("Introduceti elementele matricei: ");
        for(int i=0;i<nrLinii;i++){
            for(int j=0;j<nrColoane;j++){
                matrix[i][j] = input.nextInt();
            }
        }

        int suma = sumaDiagonalaPrincipala(matrix);
        System.out.println("Suma diagonalei principale este :" + suma);
        
    }
    public static int sumaDiagonalaPrincipala(int[][] matrix){
        int n= matrix.length;
        int sumaDiagonala = 0;
        for(int i=0;i<n;i++){
            sumaDiagonala += matrix[i][i];
        }
        return sumaDiagonala;


    }
}