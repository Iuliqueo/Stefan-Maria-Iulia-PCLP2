import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int [][]matrix1;
        int [][]matrix2;
        int [][]sum;

        matrix1 = new int[3][4];
        matrix2 = new int[3][4];
        sum = new int[3][4];


        System.out.println("Write the fisrt matrix: ");
        for(int i=0;i<3;i++){
            for(int j=0;j<4;j++){
                matrix1 [i][j] = input.nextInt();
            }
        }

        System.out.println("Write the second matrix: ");
        for(int i=0;i<3;i++){
            for(int j=0;j<4;j++){
                matrix2 [i][j] = input.nextInt();
            }
        }

        for(int i=0;i<3;i++){
            for(int j=0;j<4;j++){
                sum[i][j]=matrix1[i][j]+matrix2[i][j];
            }
        }
        System.out.println("Matrix addition: ");
        for(int i=0;i<3;i++){
            for(int j=0;j<4;j++) {
                System.out.println(sum[i][j]);
            }
            }


    }
}