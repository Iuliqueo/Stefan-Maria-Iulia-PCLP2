import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class TextToFile {
    public static void main(String[] args) {
        BufferedReader reader = null;
        FileWriter writer = null;

        try {
            reader = new BufferedReader(new InputStreamReader(System.in));


            writer = new FileWriter("output.txt");

            String line;
            System.out.println("Introduceți textul (scrieți 'exit' pentru a termina):");

            while ((line = reader.readLine()) != null) {
                if (line.equalsIgnoreCase("exit")) {
                    break;
                }
                writer.write(line + System.lineSeparator());
            }

            System.out.println("Textul a fost salvat în fișierul output.txt");

        } catch (IOException e) {
            System.err.println("A apărut o eroare: " + e.getMessage());
            e.printStackTrace();
        } finally {

            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.err.println("Eroare la închiderea BufferedReader: " + e.getMessage());
                    e.printStackTrace();
                }
            }

            
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    System.err.println("Eroare la închiderea FileWriter: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
    }
}
