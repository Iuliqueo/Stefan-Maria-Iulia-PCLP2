public class Main {
    public static void main(String[] args) {
        IceCream iceCream = new BasicIceCream();
        iceCream = new ChocolateTopping(iceCream);
        iceCream = new VanillaTopping(iceCream);

        System.out.println("Descriere: " + iceCream.getDescription());
        System.out.println("Preț: " + iceCream.getPrice());
    }
}
