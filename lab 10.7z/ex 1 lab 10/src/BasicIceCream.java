public class BasicIceCream implements IceCream{
    public BasicIceCream() {
        System.out.println("Adăugat: Basic Ice Cream");
    }

    @Override
    public String getDescription() {
        return "Basic Ice Cream";
    }

    @Override
    public double getPrice() {
        return 0.5;
    }
}

