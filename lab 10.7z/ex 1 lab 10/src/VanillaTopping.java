public class VanillaTopping extends IceCreamDecorator{
    public VanillaTopping(IceCream decoratedIceCream){
        super(decoratedIceCream);
        System.out.println("Vanilla Topping");
    }
    @Override
    public String getDescription() {
        return decoratedIceCream.getDescription() + ", Vanilla";
    }

    @Override
    public double getPrice() {
        return decoratedIceCream.getPrice() + 2.0;
    }
}
