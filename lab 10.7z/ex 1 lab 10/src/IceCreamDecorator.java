public abstract class IceCreamDecorator implements IceCream {
    protected IceCream decoratedIceCream;

    public IceCreamDecorator(IceCream decoratedIceCream) {
        this.decoratedIceCream = decoratedIceCream;
    }

    public IceCreamDecorator(int i) {
    }

    @Override
    public String getDescription() {
        return decoratedIceCream.getDescription();
    }

    @Override
    public double getPrice() {
        return decoratedIceCream.getPrice();
    }
}

