public class ChocolateTopping extends IceCreamDecorator {
    public ChocolateTopping(IceCream decoratedIceCream) {
        super(decoratedIceCream);
        System.out.println("Adăugat: Chocolate Topping");
    }

    @Override
    public String getDescription() {
        return decoratedIceCream.getDescription() + ", Chocolate";
    }

    @Override
    public double getPrice() {
        return decoratedIceCream.getPrice() + 1.5;
    }
}
