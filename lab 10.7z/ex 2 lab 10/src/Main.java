import java.io.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String filePath = "input.txt";

        try {
            printOddLines(filePath);
        } catch (IOException e) {
            System.err.println("A apărut o eroare la citirea fișierului: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public static void printOddLines(String filePath) throws IOException {
        LineNumberReader lineNumberReader = null;
        try {
            lineNumberReader = new LineNumberReader(new FileReader(filePath));
            String line;
            while ((line = lineNumberReader.readLine()) != null) {
                int lineNumber = lineNumberReader.getLineNumber();
                if (lineNumber % 2 != 0) {
                    System.out.println(lineNumber + " " + line);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Fișierul nu a fost găsit: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Eroare la citirea liniei: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (lineNumberReader != null) {
                try {
                    lineNumberReader.close();
                } catch (IOException e) {
                    System.err.println("Eroare la închiderea fișierului: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
    }
}