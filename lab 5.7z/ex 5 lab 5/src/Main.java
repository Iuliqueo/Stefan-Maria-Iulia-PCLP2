import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
            String sentence = "A batman with bat";
            String oldSubstring = "bat";
            String newSubstring = "snow";

            String newSentence = replaceSubstring(sentence, oldSubstring, newSubstring);
            System.out.println(newSentence);  // Output: "A snowman with snow"

    }
    public static String replaceSubstring(String sentence, String oldSubstring, String newSubstring) {
        return sentence.replace(oldSubstring, newSubstring);
    }
    
}