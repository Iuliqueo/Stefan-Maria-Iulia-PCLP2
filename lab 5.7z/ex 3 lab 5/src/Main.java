import java.util.Arrays;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Enter the first string: ");
        String firstString = input.nextLine();

        System.out.println("Enter the second string: ");
        String secondString = input.nextLine();

        boolean areAnagrams=areAnagrams(firstString,secondString);

        if(areAnagrams){
            System.out.println("The strings are anagrams.");
        }else{
            System.out.println("The strings are not anagrams.");
        }

    }
    public static boolean areAnagrams(String str1, String str2){
        str1 = str1.replaceAll("\\s","").toLowerCase();
        str2 = str2.replaceAll("\\s","").toLowerCase();

        if(str1.length() != str2.length()){
            return false;
        }
        char[]charArray1=str1.toCharArray();
        char[]charArray2=str2.toCharArray();

        Arrays.sort(charArray1);
        Arrays.sort(charArray2);
        return Arrays.equals(charArray1,charArray2);
    }
}