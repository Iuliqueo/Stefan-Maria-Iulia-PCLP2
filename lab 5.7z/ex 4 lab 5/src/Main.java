import java.util.Arrays;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Introduceti primul string: ");
        String firstString = input.nextLine();

        System.out.println("Introduceti al doilea string: ");
        StringBuffer secondString = new StringBuffer(input.nextLine());

        boolean comaparare = comparare(firstString,secondString); //apelez metoda de comparare

        if(comaparare){
            System.out.println("True");
        }else{
            System.out.println("False");
        }

    }
    public static boolean comparare(String str, StringBuffer strbuffer){
                //am ca parametri un string normal si unul buffer
                //creez o variabila noua de tipul string normal in care salvez convertirea buffer in string
            String str2 = strbuffer.toString();

            //returnez egalitatea stringului normal fata de cel convertit
            return str.equals(str2);
    }
}