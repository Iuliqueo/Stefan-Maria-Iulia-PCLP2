import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String str;
        System.out.println("Scrie o propozitie:");
        str = input.nextLine();

        //se initializeaza cu null ca sa acceseze dim standard (pt ca el nu stie ce dim are daca nu ii specific)
        String largest = null;
        String smallest = null;

        //creez un tablou de stringuri ca sa salvez separarea
        String[] separare = str.split(" ");

        for(int i=0; i < separare.length-1; i++ ){
            if(separare[i].length()>separare[i+1].length()){
                largest = separare[i];
                smallest=separare[i+1];
            } else {
                largest = separare[i+1];
                smallest = separare[i];
            }
        }
        System.out.println("Cel mai mare cuvant este: " + largest);
        System.out.println("Cel mai mic cuvant este: " + smallest);




    }
}