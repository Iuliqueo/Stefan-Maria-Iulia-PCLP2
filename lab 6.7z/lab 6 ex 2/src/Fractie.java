public class Fractie {
    private int numitor;
    private int numarator;

    Fractie(int numitor, int numarator){
        this.numitor = numitor;
        this.numarator = numarator;
        if(numitor == 0){
            numitor ++;
        }
    }

    public int getNumarator() {
        return numarator;
    }
    public void setNumarator(int numarator){
        this.numarator=numarator;
    }

    public int getNumitor() {
        return numitor;
    }

    public void setNumitor(int numitor) {
        this.numitor = numitor;
    }

    double suma(Fractie f1){
        double suma;
        if(f1.numitor != this.numitor){
            f1.numitor *= this.numitor;
            this.numitor *= f1.numitor;
        }
        suma=((double) this.numarator /this.numitor) + ((double) f1.numarator /f1.numitor);
        return suma;
    }


    public String toString(){
        String rezultat;
        rezultat = this.numarator + "/" + this.numitor + " = " + (this.numarator/this.numitor);
        return rezultat;
    }

    public boolean equals(Fractie f){
        if(f.numarator == this.numarator && f.numitor == this.numitor){
            return true;
        }
        else{
            return false;
        }
    }
}
