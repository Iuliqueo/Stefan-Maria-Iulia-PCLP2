public class Main{
    public static void main(String[] args) {
            Fractie f1 = new Fractie(3,2);
            Fractie f2 = new Fractie(4,5);
        System.out.println("Suma este: ");
        System.out.println(f1.suma(f2));
        System.out.println("Valoarea fractiei este: ");
        System.out.println(f1.toString());
        System.out.println("Fractiile sunt egale:");
        System.out.println(f1.equals(f2));
    }
}