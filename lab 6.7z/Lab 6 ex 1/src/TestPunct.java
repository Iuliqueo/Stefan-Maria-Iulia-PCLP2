import java.util.*;

public class TestPunct {
    public static void main(String[] args) {

        Punct A=new Punct(1,2);
        Punct B=new Punct(-1,3);
        System.out.println(A.ditance(B));

    }
}