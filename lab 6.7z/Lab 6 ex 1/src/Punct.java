import java.lang.*;

public class Punct {
    private int x;
    private int y;


    Punct() {
        this.x = 0;
        this.y = 0;
    }

    Punct(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }


    String toSring() {
        String pctString;
        pctString = "(" + this.x + " , " + this.y + ")";
        return pctString;
    }

    double distance(int x, int y) {
        double dist;
        dist = (double) Math.sqrt(Math.pow(x - this.x, 2) + Math.pow(y - this.y, 2));
        return dist;
    }
    double ditance(Punct p1){
        double distp;
        distp = Math.sqrt(Math.pow(p1.x-this.x,2) + Math.pow(p1.y-this.y,2));
        return distp;
    }
}
