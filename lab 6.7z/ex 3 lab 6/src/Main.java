import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("introduceti o valoare pentru numar: ");
        Numar numar=new Numar(input.nextInt());

        System.out.println("suma: ");
        System.out.println(numar.suma(5));
        System.out.println("suma dintre doua numere: ");
        System.out.println(numar.suma(3,4));
        System.out.println("suma dintre 3 numere: ");
        System.out.println(numar.suma(2,4,6));
        System.out.println("suma dintre 4 numere: ");
        System.out.println(numar.suma(1,3,5,7));
    }
}