public class Numar {
    private int numar;

    Numar(int a) {
        this.numar = a;
    }

    public int getNumar() {
        return numar;
    }

    public void setNumar(int numar) {
        this.numar = numar;
    }

    public int suma(int a) {
        return a + this.numar;
    }

    public int suma(int a, int b){
        return a+b;
    }

    public int suma(int a, int b, int c){
        return a+b+c;
    }

    public int suma(int a, int b, int c, int d){
        return a+b+c+d;
    }

}
