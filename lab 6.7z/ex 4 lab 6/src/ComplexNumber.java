import java.lang.Double;
public class ComplexNumber {
    private double real;
    private double imaginar;

    public double getImaginar() {
        return imaginar;
    }

    public void setImaginar(double imaginar) {
        this.imaginar = imaginar;
    }

    public double getReal() {
        return real;
    }

    public void setReal(double real) {
        this.real = real;
    }

    @Override
    String toString(){
        Double suma;
        suma = real + imaginar;
        String str;
        str = Double.toString(suma);
    }

    ComplexNumber(double r,double i){
        this.real=r;
        this.imaginar=i;
    }

    ComplexNumber(ComplexNumber numar){
        this.real= numar.real;
        this.imaginar= numar.imaginar;
    }

    ComplexNumber add( double re, double im){
        double sumre;
        double sumim;

        sumre = this.real + re;
        sumim = this.imaginar + im;

       ComplexNumber numarComplex = new ComplexNumber(sumre,sumim);
       return numarComplex;
    }

    ComplexNumber add(ComplexNumber c){
        double sumre;
        double sumim;
        sumre = this.real + c.real;
        sumim = this.imaginar + c.imaginar;

        ComplexNumber numarCompx = new ComplexNumber(sumre,sumim);
        return numarCompx;
    }

    ComplexNumber addReal(double re){
        double sumre;
        sumre = this.real + re;
        ComplexNumber numarcompx = new ComplexNumber(sumre,this.imaginar);
        return numarcompx;
    }

    ComplexNumber addIm(double im){
        double sumim;
        sumim = this.imaginar + im;
        ComplexNumber numarcompx = new ComplexNumber(this.real,sumim);
        return numarcompx;
    }
}
